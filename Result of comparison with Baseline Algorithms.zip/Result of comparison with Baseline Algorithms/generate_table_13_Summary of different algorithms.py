import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import glob
import os
import warnings
import matplotlib.pyplot as plt

# Set global font to Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'

# ==================== Global Display Name ====================
FULL_NAME = 'GNN-LSTM-PPO'
# ====================================================

warnings.filterwarnings('ignore')

# ==================== Global Settings ====================
plt.rcParams['font.size'] = 11
plt.rcParams['axes.labelsize'] = 13
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['legend.fontsize'] = 10
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['savefig.bbox'] = 'tight'

# Color Scheme
COLORS = {
    FULL_NAME: '#1f77b4',
    'Genetic Algorithm': '#ff7f0e',
    'DQN': '#d62728',
    'Random Swap': '#2ca02c',
    'Simulated Annealing': '#9467bd'
}
ALG_ORDER = [FULL_NAME, 'Genetic Algorithm', 'DQN', 'Random Swap', 'Simulated Annealing']

# Triangle Markers
TRIANGLES = {
    FULL_NAME: '^',
    'Genetic Algorithm': 's',
    'DQN': 'v',
    'Random Swap': '<',
    'Simulated Annealing': '>'
}


# ==================== Data Loading ====================
def load_raw_data():
    files = glob.glob("baseline_*_results_seed_*.xlsx")
    if not files:
        raise FileNotFoundError("No baseline_*_results_seed_*.xlsx files found")

    all_dfs = []
    for f in files:
        df = pd.read_excel(f)
        # If the 'Algorithm' column does not exist, infer from the filename
        if 'Algorithm' not in df.columns:
            base = os.path.basename(f)
            parts = base.split('_')
            if len(parts) >= 2:
                prefix = parts[1]
                alg_map = {
                    'dqn': 'DQN',
                    'full': FULL_NAME,  # Directly map to FULL_NAME
                    'ga': 'Genetic Algorithm',
                    'random': 'Random Swap',
                    'sa': 'Simulated Annealing'
                }
                alg = alg_map.get(prefix)
                if alg is None:
                    print(f"Warning: Cannot infer algorithm name from filename {f}, skipping")
                    continue
                df['Algorithm'] = alg
        else:
            # If it exists, replace 'Full (Ours)' with FULL_NAME
            df['Algorithm'] = df['Algorithm'].replace('Full (Ours)', FULL_NAME)

        # Check if all rows have Algorithm
        if df['Algorithm'].isna().any():
            print(f"Warning: Empty algorithm name in {f}, dropping these rows")
            df = df.dropna(subset=['Algorithm'])

        cost_col = None
        for col in ['Best_Cost', 'Final_Cost', 'Cost']:
            if col in df.columns:
                cost_col = col
                break
        if cost_col is None:
            print(f"Warning: No cost column in {f}, skipping")
            continue

        keep_cols = ['Algorithm', cost_col, 'Original_Cost', 'Time_sec']
        df = df[keep_cols].copy()
        df.rename(columns={cost_col: 'Cost'}, inplace=True)
        all_dfs.append(df)

    if not all_dfs:
        raise ValueError("No valid data successfully read")

    combined = pd.concat(all_dfs, ignore_index=True)
    return combined


def compute_summary(combined):
    combined['Algorithm'] = combined['Algorithm'].replace('Full (Ours)', FULL_NAME)
    # Drop empty algorithm names
    combined = combined.dropna(subset=['Algorithm'])

    summary = combined.groupby('Algorithm').agg(
        Mean_Cost=('Cost', 'mean'),
        Std_Cost=('Cost', 'std'),
        Mean_Time=('Time_sec', 'mean'),
        Original_Cost=('Original_Cost', 'first')
    ).reset_index()
    summary['Improvement_%'] = (summary['Original_Cost'] - summary['Mean_Cost']) / summary['Original_Cost'] * 100
    summary['Algorithm'] = pd.Categorical(summary['Algorithm'], categories=ALG_ORDER, ordered=True)
    summary = summary.sort_values('Algorithm').reset_index(drop=True)
    return summary


# ==================== Table 13 ====================
def export_table_13(summary):
    table_df = summary.copy()

    # Handle cases where std is empty
    table_df['Std_Cost'] = table_df['Std_Cost'].fillna(0)

    # Concatenate "mean ± std" format (keep two decimal places, with thousand separator)
    table_df['Best Cost (mean ± std)'] = table_df.apply(
        lambda row: f"{row['Mean_Cost']:,.2f} ± {row['Std_Cost']:,.2f}", axis=1
    )

    # Format other columns
    table_df['Improvement(%)'] = table_df['Improvement_%'].apply(lambda x: f"{x:.4f}")
    table_df['Computational Cost (s)'] = table_df['Mean_Time'].apply(lambda x: f"{x:.2f}")

    # Extract columns
    final_table = table_df[[
        'Algorithm',
        'Best Cost (mean ± std)',
        'Improvement(%)',
        'Computational Cost (s)'
    ]]

    # Save as Excel file
    excel_filename = 'Table13_Summary_of_different_algorithms.xlsx'
    final_table.to_excel(excel_filename, index=False)
    print(f"✅ Table saved to: {excel_filename}")

    # Print table in console
    print("\n" + "=" * 80)
    print("Table 13, Summary of different algorithms.")
    print("=" * 80)
    print(final_table.to_string(index=False))


# ==================== Main Function ====================
def main():
    print("=" * 60)
    print("Generate Table 13 results table only")
    print("=" * 60)

    try:
        combined = load_raw_data()
        summary = compute_summary(combined)

        print("\nSummary Statistics:")
        print(summary[['Algorithm', 'Mean_Cost', 'Improvement_%']])
        print()

        # ========== Generate Table 13 ==========
        export_table_13(summary)
        # ===================================

        print("\n🎉 Result generation complete!")
        print("Generated file:")
        print("  Table13_Summary_of_different_algorithms.xlsx")

    except Exception as e:
        print(f"❌ Error occurred: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()

