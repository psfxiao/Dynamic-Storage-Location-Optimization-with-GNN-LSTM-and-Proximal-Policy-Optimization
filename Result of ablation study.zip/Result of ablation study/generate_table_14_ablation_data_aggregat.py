import pandas as pd
import os

# ================= 1. Configuration Parameters =================
INIT_COST = 16226046.0

file_map = {
    "Full (Ours)": {"res": "ablation_result_Full.xlsx", "hist": "Full_ablation_full_history.xlsx"},
    "PPO_only (A)": {"res": "ablation_result_PPO_only.xlsx", "hist": "PPO_only_ablation_full_history.xlsx"},
    "PPO_GNN (B)": {"res": "ablation_result_PPO_GNN.xlsx", "hist": "PPO_GNN_ablation_full_history.xlsx"},
    "PPO_LSTM (C)": {"res": "ablation_result_PPO_LSTM.xlsx", "hist": "PPO_LSTM_ablation_full_history.xlsx"}
}

# ================= 2. Read and Calculate Data =================
rows = []
for variant, files in file_map.items():
    try:
        # 1. Read Result table
        df_res = pd.read_excel(files['res'])
        df_res.columns = df_res.columns.str.strip()
        best_cost = df_res['Best_Cost'].values[0]
        final_cost = df_res['Final_Cost'].values[0]

        # 2. Read History table (Calculate Convergence Step)
        df_hist = pd.read_excel(files['hist'])

        # Assume the 0th column is timesteps, and the last column is best_eff
        steps_data = df_hist.iloc[:, 0]  # 1st column
        eff_data = df_hist.iloc[:, -1]   # Last column

        # Find the index where eff_data (best_eff) reaches its maximum for the first time
        max_eff_idx = eff_data.idxmax()
        convergence_step = steps_data[max_eff_idx]

        # 3. Calculate Final Increase (%) = (Initial Cost - Final Cost) / Initial Cost * 100
        increase_pct = ((INIT_COST - final_cost) / INIT_COST) * 100

        rows.append({
            "Variant": variant,
            "Best Cost": best_cost,
            "Final Cost": final_cost,
            "Final Increase (%)": round(increase_pct, 2),
            "Convergence Step (s)": int(convergence_step)
        })
    except Exception as e:
        print(f"⚠️ Error processing {variant}: {e}")

df_table = pd.DataFrame(rows)

# ================= 3. Calculate Gap with Full (%) =================
if not df_table.empty:
    full_inc = df_table[df_table['Variant'] == 'Full (Ours)']['Final Increase (%)'].values[0]

    df_table['Gap with Full (%)'] = df_table['Final Increase (%)'] - full_inc
    df_table['Gap with Full (%)'] = df_table['Gap with Full (%)'].astype(object)
    df_table.loc[df_table['Variant'] == 'Full (Ours)', 'Gap with Full (%)'] = "—"

    # Adjust column order
    cols = ["Variant", "Best Cost", "Final Cost", "Final Increase (%)", "Gap with Full (%)", "Convergence Step (s)"]
    df_table = df_table[cols]

# ================= 4. Export to Excel =================
output_file = "Table 14, Ablation summary of GNN-LSTM-PPO.xlsx"
writer = pd.ExcelWriter(output_file, engine='xlsxwriter')
df_table.to_excel(writer, sheet_name='Table 14', index=False)

workbook = writer.book
worksheet = writer.sheets['Table 14']

header_format = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'border': 1})
cell_format = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'border': 1})
num_format = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'border': 1, 'num_format': '#,##0'})

for col_num, value in enumerate(df_table.columns.values):
    worksheet.write(0, col_num, value, header_format)

for row_num in range(1, len(df_table) + 1):
    for col_num in range(len(df_table.columns)):
        val = df_table.iloc[row_num - 1, col_num]
        if col_num in [1, 2]:
            worksheet.write(row_num, col_num, val, num_format)
        else:
            worksheet.write(row_num, col_num, val, cell_format)

worksheet.set_column('A:A', 18)
worksheet.set_column('B:C', 15)
worksheet.set_column('D:F', 22)
writer.close()

# ================= 5. Print table in console =================
print(f"✅ Table 14 successfully generated: {output_file}")
print("\nPreview data:")
pd.set_option('display.float_format', lambda x: '%.2f' % x)
print(df_table.to_string(index=False))