import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import ttest_ind
from matplotlib.patches import Patch

# ========== 1. Read Data ==========
ppo_file = "Repeated_costs_PPO_only.xlsx"
full_file = "Repeated_costs_Full.xlsx"

try:
    ppo_df = pd.read_excel(ppo_file)
    full_df = pd.read_excel(full_file)
except FileNotFoundError as e:
    print(f"File not found: {e}")
    exit(1)

# Extract cost columns
ppo_costs = ppo_df['Final Cost'].values
full_costs = full_df['Final Cost'].values

# Merge into long-format data
data = pd.DataFrame({
    'Cost': np.concatenate([ppo_costs, full_costs]),
    'Model': ['PPO_only'] * len(ppo_costs) + ['Full'] * len(full_costs)
})

# ========== 2. Statistical Calculation ==========
n_ppo, n_full = len(ppo_costs), len(full_costs)
mean_ppo, mean_full = np.mean(ppo_costs), np.mean(full_costs)
std_ppo, std_full = np.std(ppo_costs, ddof=1), np.std(full_costs, ddof=1)
sem_ppo, sem_full = stats.sem(ppo_costs), stats.sem(full_costs)
ci95_ppo = stats.t.interval(0.95, n_ppo-1, loc=mean_ppo, scale=sem_ppo)
ci95_full = stats.t.interval(0.95, n_full-1, loc=mean_full, scale=sem_full)

# T-test
t_stat, p_value = ttest_ind(ppo_costs, full_costs)
pooled_std = np.sqrt(((n_ppo-1)*std_ppo**2 + (n_full-1)*std_full**2) / (n_ppo+n_full-2))
cohens_d = (mean_ppo - mean_full) / pooled_std

# Print results
print("\n" + "="*80)
print("Descriptive Statistics")
print("="*80)
print(f"{'Model':<10} {'N':<5} {'Mean':<15} {'Std':<15} {'SEM':<15} {'95% CI_Low':<15} {'95% CI_High':<15}")
print(f"{'PPO_only':<10} {n_ppo:<5} {mean_ppo:>14,.2f} {std_ppo:>14,.2f} {sem_ppo:>14,.2f} {ci95_ppo[0]:>14,.2f} {ci95_ppo[1]:>14,.2f}")
print(f"{'Full':<10} {n_full:<5} {mean_full:>14,.2f} {std_full:>14,.2f} {sem_full:>14,.2f} {ci95_full[0]:>14,.2f} {ci95_full[1]:>14,.2f}")

print("\n" + "="*80)
print("T-test Results")
print("="*80)
print(f"t-statistic = {t_stat:.4f}")
print(f"p-value (two-tailed) = {p_value:.4e}")
print(f"Cohen's d = {cohens_d:.4f}")

# Save statistical tables
with pd.ExcelWriter('statistical_validation_results.xlsx') as writer:
    desc_df = pd.DataFrame({
        'Model': ['PPO_only', 'Full'],
        'N': [n_ppo, n_full],
        'Mean': [mean_ppo, mean_full],
        'Std': [std_ppo, std_full],
        'SEM': [sem_ppo, sem_full],
        '95%_CI_Low': [ci95_ppo[0], ci95_full[0]],
        '95%_CI_High': [ci95_ppo[1], ci95_full[1]]
    })
    desc_df.to_excel(writer, sheet_name='Descriptive_Stats', index=False)
    ttest_df = pd.DataFrame({
        't-statistic': [t_stat],
        'p-value': [p_value],
        "Cohen's_d": [cohens_d],
        'Significance': ['p < 0.01']
    })
    ttest_df.to_excel(writer, sheet_name='TTest_Results', index=False)
print("\n✅ Statistical tables saved to statistical_validation_results.xlsx")

# =====================================================================
# ========== 3. Plotting ==========
sns.set_style("whitegrid")
sns.set_context("notebook", font_scale=1.2)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['mathtext.fontset'] = 'stix'
colors = {'PPO_only': '#2E86AB', 'Full': '#D9534F'}


legend_elements = [Patch(facecolor='none', edgecolor='none', label='** p < 0.01')]

def add_significance_bracket(ax, x1, x2, y, p_val, text_offset=0.06):
    """Add significance brackets and p-value annotations between two bars"""
    y_range = ax.get_ylim()[1] - ax.get_ylim()[0]
    bracket_y = y + y_range * text_offset
    ax.plot([x1, x1, x2, x2], [bracket_y, bracket_y + y_range*0.02, bracket_y + y_range*0.02, bracket_y],
            color='black', linewidth=1.5)
    # Directly annotate **
    ax.text((x1+x2)/2, bracket_y + y_range*0.035, f'**\np = {p_val:.2e}',
            ha='center', va='bottom', fontsize=14, fontweight='bold')

# ===================== Figure 1: Raincloud Plot =====================
fig1, ax1 = plt.subplots(figsize=(10, 7))
violin_data = [ppo_costs, full_costs]

# Violin plot
parts = ax1.violinplot(violin_data, positions=[0, 1], widths=0.6, showmeans=False, showmedians=False)
for i, pc in enumerate(parts['bodies']):
    pc.set_facecolor(colors[['PPO_only', 'Full'][i]])
    pc.set_alpha(0.4)
    pc.set_edgecolor('black')
    pc.set_linewidth(0.8)

# Box plot
ax1.boxplot(violin_data, positions=[0, 1], widths=0.15, patch_artist=True,
            showmeans=False, showfliers=False,
            medianprops=dict(color='black', linewidth=2),
            boxprops=dict(facecolor='white', edgecolor='black', linewidth=1.2),
            whiskerprops=dict(color='black', linewidth=1.2),
            capprops=dict(color='black', linewidth=1.2))

# Raw data points
for i, costs in enumerate(violin_data):
    x_vals = np.random.normal(i, 0.04, size=len(costs))
    ax1.scatter(x_vals, costs, s=40, color='black', alpha=0.5, edgecolors='none')

# Mean star marker
ax1.scatter([0, 1], [mean_ppo, mean_full], marker='*', s=300,
            color='gold', edgecolor='black', zorder=10, label='Mean')

# Significance annotation
add_significance_bracket(ax1, 0, 1, max(np.max(ppo_costs), np.max(full_costs)), p_value)
ax1.set_ylim(ax1.get_ylim()[0], ax1.get_ylim()[1] * 1.0002)


ax1.legend(handles=legend_elements, loc='lower right', fontsize=10, framealpha=0.9)

ax1.set_xticks([0, 1])
ax1.set_xticklabels(['PPO_only', 'Full'], fontsize=13, fontweight='bold')
ax1.set_ylabel('Total Cost', fontsize=13, fontweight='bold')
ax1.set_title('(a) Raincloud Plot: Distribution of Final Costs', fontsize=14, fontweight='bold')
ax1.grid(axis='y', linestyle='--', alpha=0.4)
plt.tight_layout()
plt.savefig('Figure1_Raincloud_Plot.png', dpi=300, bbox_inches='tight')
print("✅ Figure 1 Raincloud Plot saved to Figure1_Raincloud_Plot.png")

# ===================== Figure 2: Mean Comparison Plot =====================
fig2, ax2 = plt.subplots(figsize=(9, 7))
x_pos = [0, 1]
means = [mean_ppo, mean_full]
errors = [ci95_ppo[1] - mean_ppo, ci95_full[1] - mean_full]

bars = ax2.bar(x_pos, means, width=0.5, color=[colors['PPO_only'], colors['Full']],
               edgecolor='black', linewidth=1.2, yerr=errors, capsize=6,
               error_kw={'ecolor': 'black', 'linewidth': 1.5})

for i, costs in enumerate(violin_data):
    x_vals = np.random.normal(i, 0.05, size=len(costs))
    ax2.scatter(x_vals, costs, s=40, color='black', alpha=0.4, edgecolors='none', zorder=3)

for bar in bars:
    height = bar.get_height()
    ax2.annotate(f'{height:,.0f}', xy=(bar.get_x() + bar.get_width()/2, height),
                 xytext=(0, 8), textcoords='offset points', ha='center', va='bottom',
                 fontsize=10, fontweight='bold')

add_significance_bracket(ax2, 0, 1, max(means) + max(errors) * 0.5, p_value)
ax2.set_ylim(ax2.get_ylim()[0], ax2.get_ylim()[1] * 1.2)

ax2.legend(handles=legend_elements, loc='upper right', fontsize=10, framealpha=0.9)

ax2.set_xticks(x_pos)
ax2.set_xticklabels(['PPO_only', 'Full'], fontsize=13, fontweight='bold')
ax2.set_ylabel('Total Cost (Mean ± 95% CI)', fontsize=13, fontweight='bold')
ax2.set_title('(b) Mean Comparison with 95% Confidence Intervals', fontsize=14, fontweight='bold')
ax2.grid(axis='y', linestyle='--', alpha=0.4)
plt.tight_layout()
plt.savefig('Figure2_Mean_Comparison_with_CI.png', dpi=300, bbox_inches='tight')
print("✅ Figure 2 Mean Comparison Plot saved to Figure2_Mean_Comparison_with_CI.png")


print("\n" + "="*80)
print("🎉 All statistical analysis results generated.")
print("    - Figure1_Raincloud_Plot.png")
print("    - Figure2_Mean_Comparison_with_CI.png")
print("    - statistical_validation_results.xlsx")
print("="*80)